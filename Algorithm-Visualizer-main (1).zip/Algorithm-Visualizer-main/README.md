# Algorithm-Visualizer

Open the file /MainNavigator/MainNavigator.html to use this Algorithm Visualizer 
(open with VSCode Live Server or something equivalent)